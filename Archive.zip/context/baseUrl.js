// export const baseUrl = "https://api.uhurupay.ng";
export const baseUrl = "https://upay-api.herokuapp.com";
export const token =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYxNjBjMzc4NTM1MGM0N2EzNTAzMjYzOSIsImlhdCI6MTYzNTI2MjAzNywiZXhwIjoxNjQwNDQ2MDM3fQ.02ykK7_RUEHqYOqkFgCPcvA9dqvFXvV40_54dE32lFs";
