import Form from "../../components/Login";
const Login = () => {
  return <Form />;
};
export default Login;
